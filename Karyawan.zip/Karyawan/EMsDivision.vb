﻿Public Class EMsDivision

    Public Function EAdmCode() As String
        Return "DIV.0001"
    End Function

    Public Function EAdmDsc() As String
        Return "Administration"
    End Function

    Public Function EProdCode() As String
        Return "DIV.0002"
    End Function

    Public Function EProdDsc() As String
        Return "Production"
    End Function

    Public Function EFinCode() As String
        Return "DIV.0003"
    End Function

    Public Function EFinDsc() As String
        Return "Finance"
    End Function

End Class
