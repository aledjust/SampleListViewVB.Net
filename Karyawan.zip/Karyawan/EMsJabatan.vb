﻿Public Class EMsJabatan

    Public Function EKabagCode() As String
        Return "JBT.0001"
    End Function

    Public Function EKabagDsc() As String
        Return "Kepala Bagian"
    End Function

    Public Function EWaKabagCode() As String
        Return "JBT.0002"
    End Function

    Public Function EWKabagDsc() As String
        Return "Wakil Kabag"
    End Function

    Public Function EStafCode() As String
        Return "JBT.0003"
    End Function

    Public Function EStafDsc() As String
        Return "Staf"
    End Function

End Class
